# GTA V PlayStation Cheats

For Story Mode. Enter the button combinations during gameplay.

- Invincibility: Right, X, Right, Left, Right, R1, Right, Left, X, Triangle
- Max Health & Armor: Circle, L1, Triangle, R2, X, Square, Circle, Right, Square, L1, L1, L1
- Lower Wanted Level: R1, R1, Circle, R2, Right, Left, Right, Left, Right, Left
- Raise Wanted Level: R1, R1, Circle, R2, Left, Right, Left, Right, Left, Right
- Weapons & Ammo: Triangle, R2, Left, L1, X, Right, Triangle, Down, Square, L1, L1, L1
- Parachute: Left, Right, L1, L2, R1, R2, R2, Left, Left, Right, L1
- Super Jump: Left, Left, Triangle, Triangle, Right, Right, Left, Right, Square, R1, R2
- Fast Run: Triangle, Left, Right, Right, L2, L1, Square
- Change Weather: R2, X, L1, L1, L2, L2, L2, Square
