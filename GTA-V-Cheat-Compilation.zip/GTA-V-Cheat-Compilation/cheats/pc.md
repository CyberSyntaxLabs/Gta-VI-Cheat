# GTA V PC Cheats

Enter these cheat words through the in-game PC console (`~`) in Story Mode.

| Effect | Cheat |
|---|---|
| Invincibility | `PAINKILLER` |
| Max Health & Armor | `TURTLE` |
| Weapons & Ammo | `TOOLUP` |
| Lower Wanted Level | `LAWYERUP` |
| Raise Wanted Level | `FUGITIVE` |
| Recharge Special Ability | `POWERUP` |
| Fast Run | `CATCHME` |
| Fast Swim | `GOTGILLS` |
| Super Jump | `HOPTOIT` |
| Explosive Melee | `HOTHANDS` |
| Flaming Bullets | `INCENDIARY` |
| Slow Motion Aim | `DEADEYE` |
| Drunk Mode | `LIQUOR` |
| Parachute | `SKYDIVE` |
| Spawn Buzzard | `BUZZOFF` |
| Spawn Comet | `COMET` |
| Spawn PCJ-600 | `ROCKET` |
| Spawn Sanchez | `OFFROAD` |
| Spawn BMX | `BANDIT` |
| Spawn Limo | `VINEWOOD` |
| Spawn Golf Cart | `HOLEIN1` |
| Spawn Trashmaster | `TRASHED` |
| Change Weather | `MAKEITRAIN` |
| Moon Gravity | `FLOATER` |
| Slidey Cars | `SNOWDAY` |
