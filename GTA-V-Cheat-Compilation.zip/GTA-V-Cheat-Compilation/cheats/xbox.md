# GTA V Xbox Cheats

For Story Mode. Enter the button combinations during gameplay.

- Invincibility: Right, A, Right, Left, Right, RB, Right, Left, A, Y
- Max Health & Armor: B, LB, Y, RT, A, X, B, Right, X, LB, LB, LB
- Lower Wanted Level: RB, RB, B, RT, Right, Left, Right, Left, Right, Left
- Raise Wanted Level: RB, RB, B, RT, Left, Right, Left, Right, Left, Right
- Weapons & Ammo: Y, RT, Left, LB, A, Right, Y, Down, X, LB, LB, LB
- Parachute: Left, Right, LB, LT, RB, RT, RT, Left, Left, Right, LB
- Super Jump: Left, Left, Y, Y, Right, Right, Left, Right, X, RB, RT
- Fast Run: Y, Left, Right, Right, LT, LB, X
- Change Weather: RT, A, LB, LB, LT, LT, LT, X
