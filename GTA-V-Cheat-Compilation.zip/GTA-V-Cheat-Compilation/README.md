# GTA V Cheat Compilation

A reference collection of built-in Grand Theft Auto V single-player cheat codes.

> **Scope:** These are the game's built-in cheat codes for Story Mode. They are not intended for GTA Online.

## Contents

- `cheats/pc.md` — PC console/phone cheat references
- `cheats/playstation.md` — PlayStation controller combinations
- `cheats/xbox.md` — Xbox controller combinations
- `docs/notes.md` — usage notes and limitations

## Important

Using cheats can temporarily disable achievements/trophies for the current play session. Save your game before experimenting.

This compilation does not include or distribute game files, trainers, executables, or online exploits.
